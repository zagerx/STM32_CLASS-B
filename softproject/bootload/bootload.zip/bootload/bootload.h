#ifndef __BOOTLOAD__H
#define __BOOTLOAD__H



void iap_load_app(void);
#endif
